
package usaformas;

import java.util.Scanner;

public abstract class UsaFormas {
    public static void main(String[] args) {
        float b,a,r;
        Quadrado q;
        Triangulo t;
        Circunferencia c;
        Retangulo re;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite a Base Do Quadrado: ");
        b = sc.nextFloat();
        q = new Quadrado(b);
        q.mostra();
        
        System.out.println("Digite a base do triângulo: ");
        b = sc.nextFloat();
        System.out.println("Digite a altura do Triângulo: ");
        a = sc.nextFloat();
        t = new Triangulo(b,a);
        t.mostra();
        
        System.out.println("Digite o raio da circunferencia: ");
        r = sc.nextFloat();
        c = new Circunferencia(r);
        c.mostra();
        
        System.out.println("Digite a base do retangulo: ");
        b = sc.nextFloat();
        System.out.println("Digite a altura do retangulo: ");
        a = sc.nextFloat();
        
        re = new Retangulo(b,a);
        re.mostra();
        
    }
}
