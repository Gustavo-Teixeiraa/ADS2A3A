package usaformas;
public class Circunferencia extends Forma {
    private float raio;
    
    public Circunferencia(float r) {
        this.raio = r;
    }

    public void setRaio(float r) {
        this.raio = r;
    }

    public float getRaio() {
        return this.raio;
    }

    public float area() {
        return (float) (Math.PI * Math.pow(this.raio, 2));
    }

    public float perimetro() {
        return (float) (2 * Math.PI * this.raio);
    }

    public void mostra() {
        System.out.println("Raio: " + this.raio);
        System.out.println("Área: " + area());
        System.out.println("Perímetro: " + perimetro());
    }
    
}
